import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import train_swizzle_823g as train
import render_swizzle_hd1910 as render

root = Path(__file__).resolve().parents[2]
policy = root / 'evidence/train/policy.onnx'
assert hashlib.sha256(policy.read_bytes()).hexdigest() == '50282524d226c95bf5469140714d9499e55226f67ac74ee3b680209c6441f1d8'
original = render.make_cfg
def cfg(play=False):
    result = original(play)
    result.scene.entities['robot'].spec_fn = train.spec
    return result
render.make_cfg = cfg
output = root / 'evidence/video-20261107'
render.run(SimpleNamespace(policy=str(policy), output=str(output), updates=10000, envs=1))
audit_path = output / 'render-audit.json'
audit = json.loads(audit_path.read_text())
audit['mass'] = json.loads((root / 'evidence/mass.json').read_text())
audit_path.write_text(json.dumps(audit, indent=2))
