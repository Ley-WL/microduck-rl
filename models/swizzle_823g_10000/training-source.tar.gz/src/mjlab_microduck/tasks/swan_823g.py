"""Right-foot-supported swan pose with gradual task-space amplitude."""
from copy import deepcopy
from dataclasses import dataclass
import math
import torch
from mjlab.managers import RewardTermCfg
from .flamingo_mdp import FlamingoCommand, FlamingoCommandCfg
from .microduck_flamingo_cycle_env_cfg import make_microduck_flamingo_cycle_env_cfg, MicroduckFlamingoCycleRlCfg
from .getup_mechanical_contract import edit_mechanical_spec, LIMITS
from .walk_mass_823g import apply_mass_823g
from mjlab_microduck.robot.microduck_constants import get_standup_spec


class SwanCommand(FlamingoCommand):
    def _resample_command(self, env_ids):
        super()._resample_command(env_ids)
        self._stance_side[env_ids] = 1.
        self.vel_command_b[env_ids, 1] = self.vel_command_b[env_ids, 0]


@dataclass(kw_only=True)
class SwanCommandCfg(FlamingoCommandCfg):
    def build(self, env):
        return SwanCommand(self, env)


def amplitude(env):
    if hasattr(env, "_swan_eval_amplitude"):
        return env._swan_eval_amplitude
    return min(1., .25 + .75 * env.common_step_counter / (4000 * 24))


def measurements(env):
    robot = env.scene["robot"]
    left_ids, _ = robot.find_sites(["left_foot"], preserve_order=True)
    right_ids, _ = robot.find_sites(["right_foot"], preserve_order=True)
    left = robot.data.site_pos_w[:, left_ids[0]]
    right = robot.data.site_pos_w[:, right_ids[0]]
    q = robot.data.root_link_quat_w
    forward = torch.stack((1 - 2 * (q[:, 2].square() + q[:, 3].square()),
                           2 * (q[:, 1] * q[:, 2] + q[:, 0] * q[:, 3])), -1)
    forward = forward / forward.norm(dim=-1, keepdim=True).clamp_min(1e-6)
    rear = -((left[:, :2] - right[:, :2]) * forward).sum(-1)
    height = left[:, 2] - env.scene.env_origins[:, 2]
    pitch = torch.asin(robot.data.projected_gravity_b[:, 0].clamp(-1, 1))
    return rear, height, pitch


def swan_tracking(env):
    alpha = env.command_manager.get_term("twist").alpha
    size = amplitude(env)
    rear, height, pitch = measurements(env)
    contact = env.scene.sensors["feet_ground_contact"].data.found.reshape(env.num_envs, -1)
    stance = (contact[:, 1] > 0).float()
    foot_error = ((rear - .06 * size * alpha) / .025).square()
    foot_error += ((height - .05 * size * alpha) / .020).square()
    pitch_error = ((pitch - math.radians(30) * size * alpha) / .20).square()
    return torch.exp(-foot_error - pitch_error) * stance


def posture_hint(env):
    robot = env.scene["robot"]
    alpha = env.command_manager.get_term("twist").alpha
    error = (robot.data.joint_pos - robot.data.default_joint_pos).square().mean(-1)
    # Strong HOME target on landing, freedom to find a feasible single-foot pose.
    return torch.exp(-error / .25) * (1 - alpha)


def spec():
    return apply_mass_823g(edit_mechanical_spec(get_standup_spec()))


def make_cfg(play=False):
    cfg = deepcopy(make_microduck_flamingo_cycle_env_cfg(play=play))
    cfg.scene.entities["robot"].spec_fn = spec
    cfg.actions["joint_pos"].clip = dict(LIMITS)
    cfg.sim.nconmax = 200
    cfg.sim.contact_sensor_maxmatch = 256
    cfg.episode_length_s = 14.
    cfg.commands["twist"] = SwanCommandCfg(**vars(cfg.commands["twist"]))
    cfg.commands["twist"].ramp_s = 2.
    cfg.commands["twist"].resampling_time_range = (4., 6.)
    head = cfg.commands["head_pose"]
    head.ranges = tuple((0., 0.) for _ in head.ranges)
    for key in ("pose_track", "gravity_track", "swing_foot_clear"):
        cfg.rewards.pop(key)
    cfg.rewards["swan_tracking"] = RewardTermCfg(func=swan_tracking, weight=6.)
    cfg.rewards["landing_home"] = RewardTermCfg(func=posture_hint, weight=2.)
    cfg.rewards["com_target"].weight = 4.
    cfg.rewards["stance_foot_grounded"].weight = 2.
    cfg.events["set_flamingo_cycle_state"].params["in_pose_prob"] = 0.
    cfg.curriculum.pop("in_pose_prob", None)
    # Keep physical uncertainty small while discovering this new support geometry.
    for key in ("com_range", "head_com_range"):
        cfg.curriculum.pop(key, None)
    cfg.curriculum["push_magnitude"].params["push_stages"] = [
        {"step": 0, "velocity_range": {"x": (0., 0.), "y": (0., 0.)}},
        {"step": 5000 * 24, "velocity_range": {"x": (-.05, .05), "y": (-.05, .05)}},
    ]
    return cfg


def rl_cfg():
    cfg = deepcopy(MicroduckFlamingoCycleRlCfg)
    cfg.algorithm.symmetry_cfg = None
    cfg.max_iterations = 10000
    cfg.save_interval = 250
    cfg.logger = "tensorboard"
    cfg.upload_model = False
    return cfg
