from mjlab_microduck.train_hook import maybe_submit_to_hf_jobs

# `train <task> ... --hf-jobs` submits to HF Jobs and exits here, before any
# of the cfg imports below: this module is what mjlab's plugin loader pulls
# in, and it is the only train path no install order can take from us (see
# train_hook.py). A no-op without the flag.
maybe_submit_to_hf_jobs()

from mjlab.tasks.registry import register_mjlab_task as _register_mjlab_task
from mjlab.tasks.velocity.rl import VelocityOnPolicyRunner
from mjlab_microduck.robot.hardware_profile import HD1910_PARAMS, HARDWARE_PROFILE
from mjlab_microduck.actuator.feetech_bam import FeetechBamActuatorCfg
from pathlib import Path
from copy import deepcopy
import json


def register_mjlab_task(*, task_id, env_cfg, play_env_cfg, rl_cfg, runner_cls=None):
    """Old task IDs remain usable, but may never select the old hardware."""
    for cfg in (env_cfg, play_env_cfg):
        for actuator in cfg.scene.entities["robot"].articulation.actuators:
            if (not isinstance(actuator, FeetechBamActuatorCfg)
                    or actuator.motor_name is not None
                    or not actuator.json_path
                    or Path(actuator.json_path).resolve() != HD1910_PARAMS.resolve()
                    or actuator.kp_fw != 5.0 or actuator.vin_min != 4.0):
                raise ValueError(f"{task_id}: expected {HARDWARE_PROFILE}, got {actuator}")
    # New experiments cannot overwrite/log under upstream experiment names.
    rl_cfg = deepcopy(rl_cfg)
    if "hd1910" not in rl_cfg.experiment_name.lower():
        rl_cfg.experiment_name = "hd1910_" + rl_cfg.experiment_name
    rl_cfg.logger = "tensorboard"
    _register_mjlab_task(task_id, env_cfg, play_env_cfg, rl_cfg, runner_cls)


class MicroduckOnPolicyRunner(VelocityOnPolicyRunner):
    def __init__(self, env, train_cfg: dict, log_dir=None, device="cpu", **kwargs):
        from mjlab_microduck.robot.hardware_profile import provenance
        source = provenance()
        super().__init__(env, train_cfg, log_dir, device, **kwargs)
        if log_dir:
            destination = Path(log_dir) / "hardware-profile.json"
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(json.dumps(source, indent=2) + "\n", encoding="utf-8")
        # resolve_symmetry_config injects _env into train_cfg["algorithm"]["symmetry_cfg"]
        # in-place, sharing the same dict object with self.alg.symmetry.  Replace the
        # train_cfg reference with a copy that omits _env so dump_yaml can serialize the
        # config (MjSpec is not picklable), without touching the PPO's internal reference.
        alg = train_cfg.get("algorithm", {})
        sym = alg.get("symmetry_cfg") if isinstance(alg, dict) else None
        if isinstance(sym, dict) and "_env" in sym:
            alg["symmetry_cfg"] = {k: v for k, v in sym.items() if k != "_env"}


from .microduck_velocity_env_cfg import (
    make_microduck_velocity_env_cfg,
    MicroduckRlCfg,
)
from .microduck_standup_env_cfg import (
    make_microduck_standup_env_cfg,
    MicroduckStandUpRlCfg,
)
from .microduck_velstand_env_cfg import (
    make_microduck_velstand_env_cfg,
    MicroduckVelStandRlCfg,
)
from .microduck_ground_pick_env_cfg import (
    make_microduck_ground_pick_env_cfg,
    MicroduckGroundPickRlCfg,
)
from .microduck_ball_kick_env_cfg import (
    make_microduck_ball_kick_env_cfg,
    MicroduckBallKickRlCfg,
)
from .microduck_sitstand_env_cfg import (
    make_microduck_sitstand_env_cfg,
    MicroduckSitStandRlCfg,
)
from .microduck_velocity_rollers_env_cfg import (
    make_microduck_velocity_rollers_env_cfg,
    MicroduckRollersRlCfg,
)
from .microduck_velocity_swizzle_env_cfg import (
    make_microduck_velocity_swizzle_env_cfg,
    MicroduckSwizzleRlCfg,
)
from .microduck_roller_crouch_env_cfg import (
    make_microduck_roller_crouch_env_cfg,
    MicroduckRollerCrouchRlCfg,
)
from .microduck_roller_slope_env_cfg import (
    make_microduck_roller_slope_env_cfg,
    MicroduckRollerSlopeRlCfg,
)
from .microduck_roller_standup_env_cfg import (
    make_microduck_roller_standup_env_cfg,
    MicroduckRollerStandUpRlCfg,
)
from .microduck_spin_env_cfg import (
    make_microduck_spin_env_cfg,
    MicroduckSpinRlCfg,
)
from .microduck_roulade_env_cfg import (
    make_microduck_roulade_env_cfg,
    MicroduckRouladeRlCfg,
)
from .backlash import make_backlash_variant

# Standard velocity task
from .microduck_hd1910_dance_env_cfg import make_hd1910_dance_env_cfg, HD1910DanceRlCfg
from .microduck_hd1910_dance_env_cfg import make_hd1910_dance_stable_env_cfg, HD1910DanceStableRlCfg
from .microduck_hd1910_dance_env_cfg import make_hd1910_dance_recovery_env_cfg, HD1910DanceRecoveryRlCfg
from .microduck_hd1910_dance_env_cfg import make_hd1910_dance_expressive_env_cfg, HD1910DanceExpressiveRlCfg
from .microduck_hd1910_dance_env_cfg import make_hd1910_dance_resilient_env_cfg, HD1910DanceResilientRlCfg

register_mjlab_task(
    task_id="Mjlab-Dance10Resilient-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_dance_resilient_env_cfg(),
    play_env_cfg=make_hd1910_dance_resilient_env_cfg(play=True),
    rl_cfg=HD1910DanceResilientRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Dance10Expressive-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_dance_expressive_env_cfg(),
    play_env_cfg=make_hd1910_dance_expressive_env_cfg(play=True),
    rl_cfg=HD1910DanceExpressiveRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Dance10Recovery-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_dance_recovery_env_cfg(),
    play_env_cfg=make_hd1910_dance_recovery_env_cfg(play=True),
    rl_cfg=HD1910DanceRecoveryRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Dance10Stable-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_dance_stable_env_cfg(),
    play_env_cfg=make_hd1910_dance_stable_env_cfg(play=True),
    rl_cfg=HD1910DanceStableRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Dance10-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_dance_env_cfg(),
    play_env_cfg=make_hd1910_dance_env_cfg(play=True),
    rl_cfg=HD1910DanceRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Velocity-Flat-MicroDuck",
    env_cfg=make_microduck_velocity_env_cfg(),
    play_env_cfg=make_microduck_velocity_env_cfg(play=True),
    rl_cfg=MicroduckRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-Velocity-Rough-MicroDuck",
    env_cfg=make_microduck_velocity_env_cfg(rough=True),
    play_env_cfg=make_microduck_velocity_env_cfg(play=True, rough=True),
    rl_cfg=MicroduckRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# VelStand — walking + fall recovery + body pose control in one policy.
register_mjlab_task(
    task_id="Mjlab-VelStand-Flat-MicroDuck",
    env_cfg=make_microduck_velstand_env_cfg(),
    play_env_cfg=make_microduck_velstand_env_cfg(play=True),
    rl_cfg=MicroduckVelStandRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-VelStand-Rough-MicroDuck",
    env_cfg=make_microduck_velstand_env_cfg(rough=True),
    play_env_cfg=make_microduck_velstand_env_cfg(play=True, rough=True),
    rl_cfg=MicroduckVelStandRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Stand-up task — robot starts inverted (lying on back) and must stand up
register_mjlab_task(
    task_id="Mjlab-StandUp-Flat-MicroDuck",
    env_cfg=make_microduck_standup_env_cfg(),
    play_env_cfg=make_microduck_standup_env_cfg(play=True),
    rl_cfg=MicroduckStandUpRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-StandUp-Rough-MicroDuck",
    env_cfg=make_microduck_standup_env_cfg(rough=True),
    play_env_cfg=make_microduck_standup_env_cfg(play=True, rough=True),
    rl_cfg=MicroduckStandUpRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# SitStand task — commanded sit ↔ stand in one policy, gently, head commandable
register_mjlab_task(
    task_id="Mjlab-SitStand-Flat-MicroDuck",
    env_cfg=make_microduck_sitstand_env_cfg(),
    play_env_cfg=make_microduck_sitstand_env_cfg(play=True),
    rl_cfg=MicroduckSitStandRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-SitStand-Rough-MicroDuck",
    env_cfg=make_microduck_sitstand_env_cfg(rough=True),
    play_env_cfg=make_microduck_sitstand_env_cfg(play=True, rough=True),
    rl_cfg=MicroduckSitStandRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Ground-pick task — crouch, touch the ground with the mouth tip, return to stand
register_mjlab_task(
    task_id="Mjlab-GroundPick-Flat-MicroDuck",
    env_cfg=make_microduck_ground_pick_env_cfg(),
    play_env_cfg=make_microduck_ground_pick_env_cfg(play=True),
    rl_cfg=MicroduckGroundPickRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# BallKick task — kick a 70mm/15g ball forward hard with the right foot from a
# standing start (flat terrain only — a ball on rough terrain is another task).
register_mjlab_task(
    task_id="Mjlab-BallKick-Flat-MicroDuck",
    env_cfg=make_microduck_ball_kick_env_cfg(),
    play_env_cfg=make_microduck_ball_kick_env_cfg(play=True),
    rl_cfg=MicroduckBallKickRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-GroundPick-Rough-MicroDuck",
    env_cfg=make_microduck_ground_pick_env_cfg(rough=True),
    play_env_cfg=make_microduck_ground_pick_env_cfg(play=True, rough=True),
    rl_cfg=MicroduckGroundPickRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Roller skate velocity task (passive-wheel model; historical task id kept)
register_mjlab_task(
    task_id="Mjlab-Velocity-Flat-MicroDuck-Rollers",
    env_cfg=make_microduck_velocity_rollers_env_cfg(),
    play_env_cfg=make_microduck_velocity_rollers_env_cfg(play=True),
    rl_cfg=MicroduckRollersRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Roller SWIZZLE task — clean classic swizzle (symmetric, feet grounded).
register_mjlab_task(
    task_id="Mjlab-Velocity-Swizzle-MicroDuck",
    env_cfg=make_microduck_velocity_swizzle_env_cfg(),
    play_env_cfg=make_microduck_velocity_swizzle_env_cfg(play=True),
    rl_cfg=MicroduckSwizzleRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-RollerCrouch-Flat-MicroDuck",
    env_cfg=make_microduck_roller_crouch_env_cfg(),
    play_env_cfg=make_microduck_roller_crouch_env_cfg(play=True),
    rl_cfg=MicroduckRollerCrouchRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

register_mjlab_task(
    task_id="Mjlab-RollerSlope-Flat-MicroDuck",
    env_cfg=make_microduck_roller_slope_env_cfg(),
    play_env_cfg=make_microduck_roller_slope_env_cfg(play=True),
    rl_cfg=MicroduckRollerSlopeRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Roller STANDUP — se relever sur rollers (policy dédiée, départ au sol).
register_mjlab_task(
    task_id="Mjlab-RollerStandUp-Flat-MicroDuck",
    env_cfg=make_microduck_roller_standup_env_cfg(),
    play_env_cfg=make_microduck_roller_standup_env_cfg(play=True),
    rl_cfg=MicroduckRollerStandUpRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Spin task — rotation rapide sur place, sur rollers (slot ground-pick).
register_mjlab_task(
    task_id="Mjlab-Spin-Flat-MicroDuck",
    env_cfg=make_microduck_spin_env_cfg(),
    play_env_cfg=make_microduck_spin_env_cfg(play=True),
    rl_cfg=MicroduckSpinRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Roulade — forward roll over the flat head top, land back on the feet.
register_mjlab_task(
    task_id="Mjlab-Roulade-Flat-MicroDuck",
    env_cfg=make_microduck_roulade_env_cfg(),
    play_env_cfg=make_microduck_roulade_env_cfg(play=True),
    rl_cfg=MicroduckRouladeRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

# Backlash variants — ±1° serial gear play per servo + encoder-through-backlash
# actuator feedback and joint obs (see tasks/backlash.py). Each family keeps its
# base task's collision model: Velocity → robot_walk_backlash.xml,
# VelStand → robot_allcollisions_backlash.xml, StandUp → robot_groundcontact_backlash.xml. Obs/action dims are
# unchanged vs the base tasks.
from mjlab_microduck.robot.microduck_constants import (
    MICRODUCK_ALLCOLLISIONS_BACKLASH_ROBOT_CFG,
    MICRODUCK_BACKLASH_ROBOT_CFG,
    MICRODUCK_ROLLERS_BACKLASH_ROBOT_CFG,
    MICRODUCK_WALK_BACKLASH_ROBOT_CFG,
)

# (task_id, make_fn, make_kwargs, rl_cfg, backlash robot cfg). Task ids mirror
# the base ids with "-Backlash" inserted. Walk-model tasks get the walk
# backlash robot, roller tasks the wheels+backlash robot, the rest the
# groundcontact backlash robot — same model as their base task in each case.
_BL_GROUNDCONTACT = MICRODUCK_BACKLASH_ROBOT_CFG
_BL_WALK = MICRODUCK_WALK_BACKLASH_ROBOT_CFG
_BL_ROLLERS = MICRODUCK_ROLLERS_BACKLASH_ROBOT_CFG
_BL_ALLCOLLISIONS = MICRODUCK_ALLCOLLISIONS_BACKLASH_ROBOT_CFG
_BACKLASH_TASKS = (
    ("Mjlab-Velocity-Flat-Backlash-MicroDuck", make_microduck_velocity_env_cfg, {}, MicroduckRlCfg, _BL_WALK),
    ("Mjlab-Velocity-Rough-Backlash-MicroDuck", make_microduck_velocity_env_cfg, {"rough": True}, MicroduckRlCfg, _BL_WALK),
    ("Mjlab-VelStand-Flat-Backlash-MicroDuck", make_microduck_velstand_env_cfg, {}, MicroduckVelStandRlCfg, _BL_ALLCOLLISIONS),
    ("Mjlab-VelStand-Rough-Backlash-MicroDuck", make_microduck_velstand_env_cfg, {"rough": True}, MicroduckVelStandRlCfg, _BL_ALLCOLLISIONS),
    ("Mjlab-StandUp-Flat-Backlash-MicroDuck", make_microduck_standup_env_cfg, {}, MicroduckStandUpRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-StandUp-Rough-Backlash-MicroDuck", make_microduck_standup_env_cfg, {"rough": True}, MicroduckStandUpRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-SitStand-Flat-Backlash-MicroDuck", make_microduck_sitstand_env_cfg, {}, MicroduckSitStandRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-SitStand-Rough-Backlash-MicroDuck", make_microduck_sitstand_env_cfg, {"rough": True}, MicroduckSitStandRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-GroundPick-Flat-Backlash-MicroDuck", make_microduck_ground_pick_env_cfg, {}, MicroduckGroundPickRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-GroundPick-Rough-Backlash-MicroDuck", make_microduck_ground_pick_env_cfg, {"rough": True}, MicroduckGroundPickRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-BallKick-Flat-Backlash-MicroDuck", make_microduck_ball_kick_env_cfg, {}, MicroduckBallKickRlCfg, _BL_GROUNDCONTACT),
    ("Mjlab-Velocity-Flat-Backlash-MicroDuck-Rollers", make_microduck_velocity_rollers_env_cfg, {}, MicroduckRollersRlCfg, _BL_ROLLERS),
    ("Mjlab-Velocity-Swizzle-Backlash-MicroDuck", make_microduck_velocity_swizzle_env_cfg, {}, MicroduckSwizzleRlCfg, _BL_ROLLERS),
    ("Mjlab-RollerCrouch-Flat-Backlash-MicroDuck", make_microduck_roller_crouch_env_cfg, {}, MicroduckRollerCrouchRlCfg, _BL_ROLLERS),
    ("Mjlab-RollerSlope-Flat-Backlash-MicroDuck", make_microduck_roller_slope_env_cfg, {}, MicroduckRollerSlopeRlCfg, _BL_ROLLERS),
)
for _task_id, _make_cfg, _kw, _rl_cfg, _robot_cfg in _BACKLASH_TASKS:
    register_mjlab_task(
        task_id=_task_id,
        env_cfg=make_backlash_variant(_make_cfg(**_kw), _robot_cfg),
        play_env_cfg=make_backlash_variant(_make_cfg(play=True, **_kw), _robot_cfg),
        rl_cfg=_rl_cfg,
        runner_cls=MicroduckOnPolicyRunner,
    )


from .microduck_hd1910_stand_env_cfg import make_hd1910_stand_env_cfg, HD1910StandRlCfg
register_mjlab_task(
    task_id="Mjlab-StandHold-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_stand_env_cfg(),
    play_env_cfg=make_hd1910_stand_env_cfg(play=True),
    rl_cfg=HD1910StandRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

from .microduck_hd1910_recovery_env_cfg import make_hd1910_recovery_env_cfg, HD1910RecoveryRlCfg
from .microduck_hd1910_sit_contact_env_cfg import make_hd1910_sit_contact_env_cfg, HD1910SitContactRlCfg
from .microduck_hd1910_sit_transfer_env_cfg import make_hd1910_sit_transfer_env_cfg, HD1910SitTransferRlCfg
from .microduck_hd1910_sit_process_env_cfg import make_hd1910_sit_process_env_cfg, HD1910SitProcessRlCfg
from .sit_process_ablation_env_cfg import CASES,make_sit_ablation_env_cfg,make_sit_ablation_rl_cfg
for _case in CASES:
    register_mjlab_task(
        task_id='Mjlab-SitStandProcess'+_case+'-Flat-MicroDuck-HD1910',
        env_cfg=make_sit_ablation_env_cfg(_case),
        play_env_cfg=make_sit_ablation_env_cfg(_case,play=True),
        rl_cfg=make_sit_ablation_rl_cfg(_case),
        runner_cls=MicroduckOnPolicyRunner,
    )
register_mjlab_task(
    task_id='Mjlab-SitStandProcess-Flat-MicroDuck-HD1910',
    env_cfg=make_hd1910_sit_process_env_cfg(),
    play_env_cfg=make_hd1910_sit_process_env_cfg(play=True),
    rl_cfg=HD1910SitProcessRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)
register_mjlab_task(
    task_id='Mjlab-SitStandTransfer-Flat-MicroDuck-HD1910',
    env_cfg=make_hd1910_sit_transfer_env_cfg(),
    play_env_cfg=make_hd1910_sit_transfer_env_cfg(play=True),
    rl_cfg=HD1910SitTransferRlCfg,runner_cls=MicroduckOnPolicyRunner,
)
register_mjlab_task(
    task_id='Mjlab-SitStandContact-Flat-MicroDuck-HD1910',
    env_cfg=make_hd1910_sit_contact_env_cfg(),
    play_env_cfg=make_hd1910_sit_contact_env_cfg(play=True),
    rl_cfg=HD1910SitContactRlCfg, runner_cls=MicroduckOnPolicyRunner,
)
from .microduck_hd1910_skills_env_cfg import (
    make_hd1910_getup_env_cfg, make_hd1910_sitstand_env_cfg,
    HD1910GetupRlCfg, HD1910SitStandRlCfg,
)
from .microduck_hd1910_getup_mechanical_env_cfg import make_getup_mechanical_env_cfg, GetupMechanicalRlCfg
register_mjlab_task(
    task_id='Mjlab-GetupMechanical-Flat-MicroDuck-HD1910',
    env_cfg=make_getup_mechanical_env_cfg(),
    play_env_cfg=make_getup_mechanical_env_cfg(play=True),
    rl_cfg=GetupMechanicalRlCfg, runner_cls=MicroduckOnPolicyRunner,
)
for task_id, factory, agent in (
    ("Mjlab-Getup-Flat-MicroDuck-HD1910", make_hd1910_getup_env_cfg, HD1910GetupRlCfg),
    ("Mjlab-SitStand-Flat-MicroDuck-HD1910", make_hd1910_sitstand_env_cfg, HD1910SitStandRlCfg),
):
    register_mjlab_task(task_id=task_id, env_cfg=factory(), play_env_cfg=factory(play=True),
                       rl_cfg=agent, runner_cls=MicroduckOnPolicyRunner)
register_mjlab_task(
    task_id="Mjlab-PushRecovery-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_recovery_env_cfg(),
    play_env_cfg=make_hd1910_recovery_env_cfg(play=True),
    rl_cfg=HD1910RecoveryRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)

from .microduck_hd1910_settle_env_cfg import make_hd1910_settle_env_cfg, HD1910SettleRlCfg
register_mjlab_task(
    task_id="Mjlab-PushSettle-Flat-MicroDuck-HD1910",
    env_cfg=make_hd1910_settle_env_cfg(),
    play_env_cfg=make_hd1910_settle_env_cfg(play=True),
    rl_cfg=HD1910SettleRlCfg,
    runner_cls=MicroduckOnPolicyRunner,
)
from .microduck_hd1910_sit_head_env_cfg import make_sit_head_env_cfg,SitHeadRlCfg
for _name,_penalty in [('Control',False),('Repair',True)]:
    register_mjlab_task(task_id='Mjlab-SitHead'+_name+'-Flat-MicroDuck-HD1910',env_cfg=make_sit_head_env_cfg(penalty=_penalty),play_env_cfg=make_sit_head_env_cfg(play=True,penalty=_penalty),rl_cfg=SitHeadRlCfg,runner_cls=MicroduckOnPolicyRunner)
from .microduck_hd1910_sit_pitch_env_cfg import make_sit_pitch_env_cfg,SitPitchRlCfg
for _name,_penalty in [('Control',False),('Repair',True)]:
    register_mjlab_task(task_id='Mjlab-SitPitch'+_name+'-Flat-MicroDuck-HD1910',env_cfg=make_sit_pitch_env_cfg(penalty=_penalty),play_env_cfg=make_sit_pitch_env_cfg(play=True,penalty=_penalty),rl_cfg=SitPitchRlCfg,runner_cls=MicroduckOnPolicyRunner)
from .microduck_hd1910_sit_pitch_env_cfg import SitPitchFixedRlCfg
for _name,_penalty in [('Control',False),('Repair',True)]:
    register_mjlab_task(task_id='Mjlab-SitPitchFixed'+_name+'-Flat-MicroDuck-HD1910',env_cfg=make_sit_pitch_env_cfg(penalty=_penalty),play_env_cfg=make_sit_pitch_env_cfg(play=True,penalty=_penalty),rl_cfg=SitPitchFixedRlCfg,runner_cls=MicroduckOnPolicyRunner)
from .microduck_roulade_mechanical_env_cfg import make_roll_transfer_cfg,RollTransferRlCfg
for _name,_repair in [('Control',False),('Repair',True)]:
    register_mjlab_task(task_id='Mjlab-RouladeTransfer'+_name+'-Flat-MicroDuck',env_cfg=make_roll_transfer_cfg(repair=_repair),play_env_cfg=make_roll_transfer_cfg(play=True,repair=_repair),rl_cfg=RollTransferRlCfg,runner_cls=MicroduckOnPolicyRunner)
